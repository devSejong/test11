/**
 * Provides inbound Spring Integration SIAdapterUpperPrefix components.
 */
package sipackage.inbound;