Spring Integration - Simple Standalone Template
================================================================================

This template is meant for running Spring Integration standalone (No runtime
container needed). This template by default only uses core Spring Integration
components.

You can run the application by either

* running the "Main" class from within STS (Right-click on Main class --> Run As --> Java Application)
* or from the command line:
    - mvn package
    - mvn exec:java

--------------------------------------------------------------------------------

For help please take a look at the Spring Integration documentation:

http://www.springsource.org/spring-integration

